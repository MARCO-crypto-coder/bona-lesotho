# BONA: See Lesotho Differently
Run: `npm install` then `npm start` (opens http://localhost:3000).
Structure: src/data (attractions array), src/components (Card, Detail, EnquiryForm, Scene), src/App.js (state, search/filter).
To use real photos: add an `image` field to each object in src/data/attractions.js and render <img> in AttractionCard/AttractionDetail instead of <Scene>.
