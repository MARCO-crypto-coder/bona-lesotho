import { useState, useMemo } from "react";
import { ATTRACTIONS, CATS, ACTS, HERO_IMAGE, BANNER_IMAGE, ABOUT_IMAGE, FACTS } from "./data/attractions";
import Tile from "./components/Tile";
import AttractionCard from "./components/AttractionCard";
import AttractionDetail from "./components/AttractionDetail";
import EnquiryForm, { emptyForm } from "./components/EnquiryForm";
import HeroBg from "./components/HeroBg";

export default function App() {
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState("All");
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [menu, setMenu] = useState(false);

  const list = useMemo(
    () => ATTRACTIONS.filter((a) => (cat === "All" || a.category === cat) && a.name.toLowerCase().includes(query.trim().toLowerCase())),
    [query, cat]
  );
  const plan = (a, n) => {
    setForm({ ...form, dest: a.name, visitors: n });
    setSelected(null);
    setTimeout(() => document.getElementById("enquire").scrollIntoView(), 50);
  };
  const close = () => setMenu(false);

  return (
    <div>
      <header><div className="wrap">
        <div className="logo">B<b>◉</b>NA</div>
        <button className="burger" onClick={() => setMenu(!menu)} aria-label="Menu">☰</button>
        <nav className={menu ? "open" : ""}>
          <a href="#home" onClick={close}>Home</a>
          <a href="#discover" onClick={close}>Attractions</a>
          <a href="#activities" onClick={close}>Activities</a>
          <a href="#enquire" onClick={close}>Plan Your Visit</a>
        </nav>
      </div></header>

      <div className={"hero" + (HERO_IMAGE ? " photo" : "")} id="home" style={HERO_IMAGE ? { backgroundImage: `url(${HERO_IMAGE})` } : undefined}>{!HERO_IMAGE && <HeroBg />}<div className="wrap">
        <div className="eyebrow" >BONA · Sesotho for “see”</div>
        <h1>See Lesotho Differently.</h1>
        <p>Discover extraordinary places, experiences and stories across the Mountain Kingdom.</p>
        <a className="btn" href="#discover">Explore Lesotho</a>
        <a className="btn ghost" href="#enquire">Plan Your Visit</a>
      </div></div>

      <div className="strip"><div className="wrap">{FACTS.map((f) => <span key={f}>{f}</span>)}</div></div>

      <section><div className="wrap about"><div>
        <div className="eyebrow">The Kingdom in the Sky</div>
        <h2>About Lesotho</h2>
        <p style={{ maxWidth: 680 }}>Lesotho is a small, landlocked country entirely above 1,400 m, surrounded by South Africa. Known for dramatic highlands, Basotho blankets, pony trekking and warm hospitality, it offers travellers a landscape and culture found nowhere else.</p>
        <div className="facts">
          {[["Maseru", "Capital"], ["1,400 m+", "Lowest point"], ["Sesotho & English", "Languages"], ["Loti (M)", "Currency"]].map((x) => (
            <div className="fact" key={x[1]}><b>{x[0]}</b><span className="muted">{x[1]}</span></div>
          ))}
        </div>
        </div>
        <img className="about-img" src={ABOUT_IMAGE} alt="Thatched rondavels below the Maloti mountains" loading="lazy" />
      </div></section>

      <section style={{ background: "var(--sand)" }}><div className="wrap">
        <div className="eyebrow">Featured</div>
        <h2>Featured destinations</h2>
        <div className="mosaic">
          <Tile a={ATTRACTIONS[0]} onOpen={setSelected} className="tall" />
          <Tile a={ATTRACTIONS[3]} onOpen={setSelected} />
          <Tile a={ATTRACTIONS[2]} onOpen={setSelected} />
        </div>
      </div></section>

      <section id="activities"><div className="wrap">
        <div className="eyebrow">Experience</div>
        <h2>Popular activities</h2>
        <div className="acts">{ACTS.map((a) => <div className="act" key={a}>{a}</div>)}</div>
      </div></section>

      <section style={{ paddingTop: 0 }}><div className="wrap">
        <div className="banner" style={BANNER_IMAGE ? { backgroundImage: `url(${BANNER_IMAGE})` } : undefined}><div>
          <h2>Turn discovery into a plan</h2>
          <p>Pick a destination, set your group size and see an instant cost estimate.</p>
          <a className="btn" href="#discover">Start planning</a>
        </div></div>
      </div></section>

      <section id="discover" style={{ paddingTop: 20 }}><div className="wrap">
        <div className="eyebrow">Discover</div>
        <h2>Where will you go next?</h2>
        <div className="bar"><input type="search" placeholder="Search places…" aria-label="Search attractions" value={query} onChange={(e) => setQuery(e.target.value)} /></div>
        <div className="pills">{CATS.map((c) => <button key={c} className={c === cat ? "on" : ""} onClick={() => setCat(c)}>{c}</button>)}</div>
        <p className="muted sans">{list.length} place{list.length === 1 ? "" : "s"} found</p>
        {list.length ? (
          <div className="grid">{list.map((a) => <AttractionCard key={a.id} a={a} onOpen={setSelected} />)}</div>
        ) : (
          <p>No attractions match your search. Try a different name or category.</p>
        )}
      </div></section>

      <section id="enquire"><div className="wrap">
        <div className="eyebrow">Plan</div>
        <h2>Visitor enquiry</h2>
        <p className="muted">Tell us where you want to go and we will help turn discovery into a plan.</p>
        <EnquiryForm form={form} setForm={setForm} />
      </div></section>

      <footer><div className="wrap">BONA: See Lesotho Differently. Costs shown are rough estimates for planning only.</div></footer>
      {selected && <AttractionDetail key={selected.id} a={selected} onClose={() => setSelected(null)} onPlan={plan} />}
    </div>
  );
}
