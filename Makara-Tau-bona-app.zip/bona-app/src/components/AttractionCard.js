import Photo from "./Photo";
import PinIcon from "./PinIcon";
export default function AttractionCard({ a, onOpen }) {
  return (
    <article className="card">
      <div className="thumb">
        <Photo src={a.image} hue={a.hue} alt={a.name} />
        <span className="tag">{a.category}</span>
      </div>
      <div className="body">
        <h3>{a.name}</h3>
        <div className="loc"><PinIcon />{a.location}</div>
        <p className="desc">{a.description}</p>
        <ul className="chips">{a.activities.slice(0, 3).map((x) => <li key={x}>{x}</li>)}</ul>
        <div className="foot">
          <span className="price"><small>From</small> M{a.cost}<small> / person</small></span>
          <button className="more" onClick={() => onOpen(a)}>View details <span>→</span></button>
        </div>
      </div>
    </article>
  );
}
