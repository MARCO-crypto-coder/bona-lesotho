export default function HeroBg() {
  return (
    <svg viewBox="0 0 800 400" preserveAspectRatio="xMidYMax slice" aria-hidden="true">
      <polygon points="0,400 0,230 140,120 260,220 400,90 540,230 680,140 800,230 800,400" fill="#333" />
      <polygon points="0,400 0,300 160,220 300,300 460,200 620,310 800,240 800,400" fill="#14213d" />
    </svg>
  );
}
