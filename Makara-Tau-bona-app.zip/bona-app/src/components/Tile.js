import Photo from "./Photo";
export default function Tile({ a, onOpen, className = "" }) {
  return (
    <div className={"tile " + className} onClick={() => onOpen(a)} role="button" tabIndex={0}
         onKeyDown={(e) => e.key === "Enter" && onOpen(a)}>
      <Photo src={a.image} hue={a.hue} alt={a.name} />
      <div className="tile-text">
        <h3>{a.name}</h3>
        <p>{a.description}</p>
        <span className="btn">SEE MORE</span>
      </div>
    </div>
  );
}
