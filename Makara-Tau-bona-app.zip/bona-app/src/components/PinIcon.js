export default function PinIcon() {
  return (
    <svg className="pin" viewBox="0 0 24 24" width="14" height="14" aria-hidden="true">
      <path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.500a2.500 2.500 0 0 1 0 5z" fill="currentColor" />
    </svg>
  );
}
