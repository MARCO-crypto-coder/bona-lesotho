import { useState } from "react";
import Scene from "./Scene";
// Shows the photo if `src` is set and loads; otherwise falls back to the generated illustration.
export default function Photo({ src, hue, alt = "" }) {
  const [broken, setBroken] = useState(false);
  if (!src || broken) return <Scene hue={hue} />;
  return <img src={src} alt={alt} loading="lazy" onError={() => setBroken(true)} />;
}
