// Generated landscape used in place of photos. Replace with <img src={a.image}> when you add real images.
export default function Scene({ hue }) {
  const c = (l, s) => `hsl(${hue},${s}%,${l}%)`;
  return (
    <svg viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <defs><linearGradient id={"g" + hue} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={c(75, 45)} /><stop offset="1" stopColor="#f0e4cc" /></linearGradient></defs>
      <rect width="400" height="200" fill={`url(#g${hue})`} />
      <circle cx="310" cy="52" r="22" fill="#fff" opacity=".85" />
      <polygon points="0,200 0,120 70,60 130,115 190,50 270,130 330,80 400,125 400,200" fill={c(42, 30)} />
      <polygon points="0,200 0,150 60,110 120,150 200,95 280,155 350,120 400,150 400,200" fill={c(28, 30)} />
      <polygon points="0,200 0,175 90,150 170,178 260,145 340,175 400,160 400,200" fill={c(16, 25)} />
    </svg>
  );
}
