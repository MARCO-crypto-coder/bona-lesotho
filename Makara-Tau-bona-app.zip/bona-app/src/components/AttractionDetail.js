import { useState } from "react";
import Photo from "./Photo";
import PinIcon from "./PinIcon";
export default function AttractionDetail({ a, onClose, onPlan }) {
  const [n, setN] = useState(2);
  return (
    <div className="modal" onClick={onClose}>
      <div className="sheet" role="dialog" aria-label={a.name} onClick={(e) => e.stopPropagation()}>
        <Photo src={a.image} hue={a.hue} alt={a.name} />
        <div className="in">
          <button className="x" onClick={onClose} aria-label="Close">×</button>
          <span className="tag">{a.category}</span>
          <h2>{a.name}</h2>
          <div className="loc"><PinIcon />{a.location}</div>
          <p>{a.story}</p>
          <div className="four">
            <div><b>SEE</b>{a.description}</div>
            <div><b>EXPERIENCE</b>{a.activities.join(" · ")}</div>
            <div><b>PLAN</b>Estimated M{a.cost} per person</div>
            <div><b>ENQUIRE</b>Ask us about guides, transport and stays</div>
          </div>
          <div className="est">
            <div>
              <div style={{ fontSize: 13 }}>Number of visitors</div>
              <div className="qty">
                <button onClick={() => setN(Math.max(1, n - 1))} aria-label="Fewer">−</button>
                <b>{n}</b>
                <button onClick={() => setN(Math.min(20, n + 1))} aria-label="More">+</button>
              </div>
            </div>
            <div>
              <div style={{ fontSize: 13 }}>Estimated cost</div>
              <div className="total">M{(n * a.cost).toLocaleString()}</div>
            </div>
            <button className="btn" onClick={() => onPlan(a, n)}>Plan this visit →</button>
          </div>
        </div>
      </div>
    </div>
  );
}
