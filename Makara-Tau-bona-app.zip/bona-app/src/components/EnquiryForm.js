import { useState } from "react";
import { ATTRACTIONS } from "../data/attractions";

export const emptyForm = { name: "", email: "", phone: "", dest: "", visitors: 1, date: "", message: "" };

function validate(f) {
  const e = {};
  if (f.name.trim().length < 3) e.name = "Please enter your full name (at least 3 characters).";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email)) e.email = "Enter a valid email address, e.g. name@example.com.";
  if (!/^\+?[0-9\s-]{7,15}$/.test(f.phone)) e.phone = "Enter a valid phone number (7 to 15 digits).";
  if (!f.dest) e.dest = "Please select a destination.";
  if (!(+f.visitors >= 1 && +f.visitors <= 50)) e.visitors = "Visitors must be between 1 and 50.";
  if (!f.date) e.date = "Choose a preferred visit date.";
  else if (f.date < new Date().toISOString().slice(0, 10)) e.date = "The date cannot be in the past.";
  if (f.message.trim().length < 10) e.message = "Please write a message of at least 10 characters.";
  return e;
}

export default function EnquiryForm({ form, setForm }) {
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(null);

  const change = (k) => (ev) => {
    setForm({ ...form, [k]: ev.target.value });
    if (errors[k]) setErrors({ ...errors, [k]: undefined });
  };
  const submit = (ev) => {
    ev.preventDefault();
    const e = validate(form);
    setErrors(e);
    if (Object.keys(e).length === 0) setSent(form);
  };
  const Err = ({ k }) => (errors[k] ? <div className="err">{errors[k]}</div> : null);

  if (sent)
    return (
      <div className="ok">
        <h2>Thank you, {sent.name.split(" ")[0]}!</h2>
        <p>Your enquiry about {sent.dest} for {sent.visitors} visitor(s) on {sent.date} has been received. We will contact you at {sent.email} shortly.</p>
        <button className="btn" onClick={() => { setSent(null); setForm(emptyForm); }}>Send another enquiry</button>
      </div>
    );

  return (
    <form onSubmit={submit} noValidate>
      <div><label htmlFor="name">Full name</label>
        <input id="name" value={form.name} onChange={change("name")} className={errors.name ? "bad" : ""} /><Err k="name" /></div>
      <div><label htmlFor="email">Email</label>
        <input id="email" type="email" value={form.email} onChange={change("email")} className={errors.email ? "bad" : ""} /><Err k="email" /></div>
      <div><label htmlFor="phone">Phone number</label>
        <input id="phone" type="tel" value={form.phone} onChange={change("phone")} className={errors.phone ? "bad" : ""} /><Err k="phone" /></div>
      <div><label htmlFor="dest">Selected destination</label>
        <select id="dest" value={form.dest} onChange={change("dest")} className={errors.dest ? "bad" : ""}>
          <option value="">Choose…</option>
          {ATTRACTIONS.map((a) => <option key={a.id} value={a.name}>{a.name}</option>)}
        </select><Err k="dest" /></div>
      <div><label htmlFor="visitors">Number of visitors</label>
        <input id="visitors" type="number" min="1" max="50" value={form.visitors} onChange={change("visitors")} className={errors.visitors ? "bad" : ""} /><Err k="visitors" /></div>
      <div><label htmlFor="date">Preferred visit date</label>
        <input id="date" type="date" value={form.date} onChange={change("date")} className={errors.date ? "bad" : ""} /><Err k="date" /></div>
      <div className="full"><label htmlFor="message">Message</label>
        <textarea id="message" rows="4" value={form.message} onChange={change("message")} className={errors.message ? "bad" : ""} /><Err k="message" /></div>
      <div className="full"><button className="btn dark" type="submit">Send enquiry</button></div>
    </form>
  );
}
